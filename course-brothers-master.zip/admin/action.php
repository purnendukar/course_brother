<?php 
if (isset($_POST['submit'])) {
	$sql = "INSERT INTO  ()
VALUES ()";
 if ($conn->query($sql) === TRUE) {
     echo "<script>alert('New record created successfully');</script>";
  }  else {
    echo "Error: " . $sql . "<br>" . $conn->error;
 }
}
?>
<?php 
if (isset($_POST['submit2'])) {
	$sql = "INSERT INTO  ()
VALUES ()";
 if ($conn->query($sql) === TRUE) {
     echo "<script>alert('New record created successfully');</script>";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
 }
}
?>
<?php 
if (isset($_POST['submit3'])) {
	$sql = "INSERT INTO  ()
VALUES ()";
 if ($conn->query($sql) === TRUE) {
     echo "<script>alert('New record created successfully');</script>";
   } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
 }
}
?>
<?php 
if (isset($_POST['submit4'])) {
	$sql = "INSERT INTO  ()
VALUES ()";
 if ($conn->query($sql) === TRUE) {
     echo "<script>alert('New record created successfully');</script>";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
 }
}
?>
