<div class="back-to-top" title='Back to top'>
  <i class='fa fa-angle-up'></i>
</div>